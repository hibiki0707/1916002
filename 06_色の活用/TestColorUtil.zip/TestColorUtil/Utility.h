#pragma once
class Utility
{

public:

	// ���`���
	static float Lerp(float start, float end, float t);

};

